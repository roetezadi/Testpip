import tensorflow as tf

print(tf.__version__)

def function_call():
	return
